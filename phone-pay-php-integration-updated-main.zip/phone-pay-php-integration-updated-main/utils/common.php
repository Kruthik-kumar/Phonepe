<?php

function getTransactionID(){

    return rand(1111111111,99999999999);
}

?>